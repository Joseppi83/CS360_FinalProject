package com.example.josephcollett_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

public class SettingsActivity extends AppCompatActivity {

    Button buttonBack;
    Switch switchSMS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);

        // Receive userId from EventsListingActivity
        Intent intent = getIntent();
        int userId = intent.getIntExtra("userId", -100);

        // Buttons
        buttonBack = findViewById(R.id.buttonBack);
        switchSMS = findViewById(R.id.switchSMS);

        // Button click listeners
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get intent for events listing screen
                Intent intent = new Intent(SettingsActivity.this, EventsListingActivity.class);

                //Pass the user ID to the next activity
                intent.putExtra("userId", userId);

                // Start the events listing activity
                startActivity(intent);

            }
        });

        // Switch listener
        // Set the initial state of the switch based on the user's preference
        boolean isSMSNotificationOn = getSharedPreferences("my_prefs", MODE_PRIVATE).getBoolean("isSMSNotificationOn", false);
        switchSMS.setChecked(isSMSNotificationOn);

        // Listen for changes to the switch
        switchSMS.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Save the user's preference
                getSharedPreferences("my_prefs", MODE_PRIVATE).edit().putBoolean("isSMSNotificationOn", isChecked).apply();

                Toast.makeText(SettingsActivity.this, "SMS preferences have changed.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
