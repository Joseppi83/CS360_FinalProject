package com.example.josephcollett_project;

import androidx.annotation.NonNull;

public class EventModel {

    //Class variables
    private int id;
    private String date;
    private String time;
    private String description;

    //Constructor
    public EventModel(int id, String date, String time, String description) {
        this.id = id;
        this.date = date;
        this.time = time;
        this.description = description;
    }

    //toString method to print the events list


    @NonNull
    @Override
    public String toString() {
        return "EventModel{" +
                "id=" + id +
                ", date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", description='" + description + '\'' +
                '}';
    }

    // Getters/Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
