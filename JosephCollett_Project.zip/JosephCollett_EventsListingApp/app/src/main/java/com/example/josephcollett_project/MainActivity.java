package com.example.josephcollett_project;

import com.example.josephcollett_project.EventsListingActivity;
import com.example.josephcollett_project.SettingsActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    // Button references and layout controls
    Button buttonLogin, buttonRegister;
    EditText editTextLoginEmailAddress, editTextLoginPassword, editTextRegisterEmailAddress,
            editTextRegisterPassword;

    int userId;

    // Methods for screen transitions after Login, Register, and clicking Settings button
    public void onLoginRegisterSuccess(int userId) {
        //Get intent for events listing screen
        Intent intent = new Intent(MainActivity.this, EventsListingActivity.class);

        //Pass the user ID to the next activity
        intent.putExtra("userId", userId);

        // Start the events listing activity
        startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);

        editTextLoginEmailAddress = findViewById(R.id.editTextLoginEmailAddress);
        editTextLoginPassword = findViewById(R.id.editTextLoginPassword);
        editTextRegisterEmailAddress = findViewById(R.id.editTextRegisterEmailAddress);
        editTextRegisterPassword = findViewById(R.id.editTextRegisterPassword);

        //Button click listeners
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userEmail = editTextLoginEmailAddress.getText().toString();
                String userPassword = editTextLoginPassword.getText().toString();

                if (!userEmail.isEmpty() && !userPassword.isEmpty()) {
                    DatabaseHelper databaseHelper = new DatabaseHelper(MainActivity.this, "user" +
                            ".db");
                    int userId = databaseHelper.findUser(userEmail, userPassword);

                    if (userId != -1) {
                        Toast.makeText(MainActivity.this, "User found with ID: " + userId, Toast.LENGTH_SHORT).show();
                        onLoginRegisterSuccess(userId);
                    } else {
                        Toast.makeText(MainActivity.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "You must enter valid values for each field.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterUserModel registerUserModel;

                String registerEmail = editTextRegisterEmailAddress.getText().toString();
                String registerPassword = editTextRegisterPassword.getText().toString();

                if ((registerEmail != null && !registerEmail.isEmpty()) &&
                        (registerPassword != null && !registerPassword.isEmpty())) {
                    try {
                        registerUserModel = new RegisterUserModel(-1,
                                registerEmail,
                                registerPassword);

                        Toast.makeText(MainActivity.this, registerUserModel.toString(),
                                        Toast.LENGTH_SHORT)
                                .show();
                    } catch (Exception err) {
                        Toast.makeText(MainActivity.this, "Invalid values for fields.",
                                Toast.LENGTH_SHORT).show();
                        registerUserModel = new RegisterUserModel(-1, "Email error", "Password " +
                                "error");
                    }
                } else {
                    Toast.makeText(MainActivity.this, "You must enter valid values for each " +
                                    "field.",
                            Toast.LENGTH_SHORT).show();

                    registerUserModel = new RegisterUserModel(-1, "Email error", "Password " +
                            "error");
                }
                DatabaseHelper databaseHelper = new DatabaseHelper(MainActivity.this, "user.db");

                // In DatabaseHelper, returns the user ID for success and -1 for FAIL
                //int success = databaseHelper.createUser(registerUserModel);
                userId = databaseHelper.createUser(registerUserModel);

                Toast.makeText(MainActivity.this, "User ID: " + userId, Toast.LENGTH_SHORT).show();

                if (userId > -1) {
                    Toast.makeText(MainActivity.this, "Redirecting to events listing screen " +
                                    "activity.",
                            Toast.LENGTH_SHORT).show();
                    onLoginRegisterSuccess(userId);
                } else {
                    Toast.makeText(MainActivity.this, "Hmmm.  Something went wrong.  Try again.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
