package com.example.josephcollett_project;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // SQLite DB Table declarations
    // DB cleanup vars
    SQLiteDatabase db;
    Cursor cursor;

    // User table declarations
    public static final String USER_TABLE = "USER_TABLE";
    public static final String COLUMN_USER_ID = "ID";
    public static final String COLUMN_USER_EMAIL = "USER_EMAIL";
    public static final String COLUMN_USER_PASSWORD = "USER_PASSWORD";
    public static final String createNewUserTableStmt =
            "CREATE TABLE " + USER_TABLE + " (" + COLUMN_USER_ID + " INTEGER " +
                    "PRIMARY KEY AUTOINCREMENT, " + COLUMN_USER_EMAIL + " TEXT UNIQUE, " + COLUMN_USER_PASSWORD + " TEXT)";

    // User events table declarations
    public static final String USER_EVENTS_TABLE = "USER_EVENTS_TABLE";
    public static final String COLUMN_EVENT_ID = "ID";

    // Column for user ID
    public static final String COLUMN_USER_ID_EVENTS = "USER_ID";
    public static final String COLUMN_EVENT_DATE = "EVENT_DATE";
    public static final String COLUMN_EVENT_TIME = "EVENT_TIME";
    public static final String COLUMN_EVENT_DESCRIPTION = "EVENT_DESCRIPTION";
    public static final String createEventsTableStmt =
            "CREATE TABLE " + USER_EVENTS_TABLE + " (" +
                    COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USER_ID_EVENTS + " INTEGER, " +
                    COLUMN_EVENT_DATE + " TEXT, " +
                    COLUMN_EVENT_TIME + " TEXT, " +
                    COLUMN_EVENT_DESCRIPTION + " TEXT, " +
                    "FOREIGN KEY (" + COLUMN_USER_ID_EVENTS + ") REFERENCES " + USER_TABLE + "(" + COLUMN_USER_ID + ")" +
                    ")";


    public DatabaseHelper(@Nullable Context context, @Nullable String name) {
        super(context, name, null, 1);
    }

    // Called first time db is created
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = createNewUserTableStmt;
        String createEventsTableStatement = createEventsTableStmt;

        db.execSQL(createTableStatement);
        db.execSQL(createEventsTableStatement);
    }

    // Called on db update
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    // Method to retrieve user ID from db after login and register success
    public String getUser(String userEmail) {
        // Query user ID from db with userEmail

        // Parse int to String

        return "";
    }

    // DB cleanup
    public void dbCleanup() {
        // DB cleanup
        if (cursor != null) {
            cursor.close();

        }
        if (db != null) {

            db.close();
        }
    }

    // Find user
    // Method to find a user in the database
    @SuppressLint("Range")
    public int findUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USER_EMAIL + " = ? AND " + COLUMN_USER_PASSWORD + " = ?";
        String[] selectionArgs = {email, password};
        Cursor cursor = db.query(USER_TABLE, columns, selection, selectionArgs, null, null, null);

        int userId = -1; // Default value if user is not found

        if (cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID));
        }

        cursor.close();
        db.close();
        return userId;
    }

    // Create new user
    public int createUser(RegisterUserModel registerUserModel) {
        db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();


        String userEmail = registerUserModel.getEmail();
        String userPassword = registerUserModel.getPassword();

        cv.put(COLUMN_USER_EMAIL, userEmail);
        cv.put(COLUMN_USER_PASSWORD, userPassword);

        // If insert is successful, long will be positive.
        // If insert is a fail, long will be -1
        long insert = db.insert(USER_TABLE, null, cv);

        if (insert > -1) {
            // Get User ID from DB to pass from activity to activity as String to get user events
            String query = "SELECT id FROM " + USER_TABLE + " WHERE " + COLUMN_USER_EMAIL + " = ?" +
                    " " +
                    "LIMIT 1;";
            int userId = -1;
            cursor = db.rawQuery(query, new String[]{userEmail});
            if (cursor.moveToFirst()) {
                userId = cursor.getInt(0);
                //DB Cleanup
                dbCleanup();
                //return userId;
                return userId;
            } else {
                return -1;
            }
        } else {
            // Fail: User ID is -1 for fail
            return -1;
        }
    }

    // Create event
    public boolean createEvent(int userId, EventModel eventModel) {
        db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_USER_ID_EVENTS, userId);  // Set the user ID in the event row
        cv.put(COLUMN_EVENT_DATE, eventModel.getDate());
        cv.put(COLUMN_EVENT_TIME, eventModel.getTime());
        cv.put(COLUMN_EVENT_DESCRIPTION, eventModel.getDescription());

        long insert = db.insert(USER_EVENTS_TABLE, null, cv);

        // Insert returns true for success and false for fail
        boolean insertSuccess = insert != -1;

        dbCleanup();

        return insertSuccess;
    }


    // List events
    public List<EventModel> getAllEvents(int userId) {
        List<EventModel> eventsList = new ArrayList<>();

        if (userId >= 0) {
            String queryString = "SELECT * FROM " + USER_EVENTS_TABLE +
                    " WHERE " + COLUMN_USER_ID_EVENTS + " = " + userId;

            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery(queryString, null);

            if (cursor.moveToFirst()) {
                // Loop through the results to create list
                do {
                    @SuppressLint("Range") int userEventId = cursor.getInt(cursor.getColumnIndex(COLUMN_EVENT_ID));
                    @SuppressLint("Range") String eventDate = cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_DATE));
                    @SuppressLint("Range") String eventTime = cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_TIME));
                    @SuppressLint("Range") String eventDescription = cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_DESCRIPTION));

                    EventModel eventListItem = new EventModel(userEventId, eventDate,
                            eventTime, eventDescription);
                    eventsList.add(eventListItem);

                } while (cursor.moveToNext());
            }

            cursor.close();  // Close the cursor
            return eventsList;
        } else {
            return eventsList;
        }

    }


    // Update event
    public boolean updateEvent(int eventId, String eventDate, String eventTime,
                               String eventDescription) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_EVENT_DATE, eventDate);
        cv.put(COLUMN_EVENT_TIME, eventTime);
        cv.put(COLUMN_EVENT_DESCRIPTION, eventDescription);

        int update = db.update(USER_EVENTS_TABLE, cv, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});

        dbCleanup();

        return update > 0;
    }

    // Delete event
    public boolean deleteEvent(int eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int delete = db.delete(USER_EVENTS_TABLE, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});

        dbCleanup();

        return delete > 0;
    }
};
