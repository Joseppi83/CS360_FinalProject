package com.example.josephcollett_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class EventsListingActivity extends AppCompatActivity {
    // Button and layout controls
    Button buttonSettings, buttonAddEvent, buttonUpdateEvent, buttonDeleteEvent;

    EditText editTextDate, editTextTime, editTextDescription;

    ListView listViewEventsListing;

    DatabaseHelper dataBaseHelper;

    ArrayAdapter<EventModel> eventArrayAdapter;

    public EventModel selectedEvent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.events_listing);

        // Receive the user ID from the Intent object
        Intent intent = getIntent();
        int userId = intent.getIntExtra("userId", -100);

        // Buttons
        buttonSettings = findViewById(R.id.buttonSettings);
        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        buttonUpdateEvent = findViewById(R.id.buttonUpdateEvent);
        buttonDeleteEvent = findViewById(R.id.buttonDeleteEvent);

        // Edit text
        editTextDate = findViewById(R.id.editTextDate);
        editTextTime = findViewById(R.id.editTextTime);
        editTextDescription = findViewById(R.id.editTextDescription);

        // List view
        listViewEventsListing = findViewById(R.id.listViewEventsListing);

        // Database helper
        dataBaseHelper = new DatabaseHelper(EventsListingActivity.this, "user.db");

        eventArrayAdapter = new ArrayAdapter<EventModel>(EventsListingActivity.this,
                android.R.layout.simple_list_item_1, dataBaseHelper.getAllEvents(userId));

        listViewEventsListing.setAdapter(eventArrayAdapter);

        // Load the events list
        loadEvents(userId);

        //Button click listeners
        buttonSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get intent for events listing screen
                Intent intent = new Intent(EventsListingActivity.this, SettingsActivity.class);

                //Pass the user ID to the next activity
                intent.putExtra("userId", userId);

                // Start the events listing activity
                startActivity(intent);
            }
        });

        buttonAddEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EventModel eventModel;

                String eventDate = editTextDate.getText().toString();
                String eventTime = editTextTime.getText().toString();
                String eventDescription = editTextDescription.getText().toString();

                    try {
                        eventModel = new EventModel(userId,
                                eventDate,
                                eventTime, eventDescription);

                        Toast.makeText(EventsListingActivity.this, eventModel.toString(),
                                        Toast.LENGTH_SHORT)
                                .show();
                    } catch (Exception err) {
                        Toast.makeText(EventsListingActivity.this, "Invalid values for fields.",
                                Toast.LENGTH_SHORT).show();
                        eventModel = new EventModel(-1, "Empty date", "Empty time",
                                "Empty description");
                    }

                DatabaseHelper databaseHelper = new DatabaseHelper(EventsListingActivity.this,
                        "user.db");

                boolean success = databaseHelper.createEvent(userId, eventModel);

                Toast.makeText(EventsListingActivity.this, "Successful? " + success, Toast.LENGTH_SHORT).show();

                if (success) {
                    // Toast user successful add
                    Toast.makeText(EventsListingActivity.this, "Event added!",
                            Toast.LENGTH_SHORT).show();
                    loadEvents(userId);
                } else {
                    Toast.makeText(EventsListingActivity.this, "ERROR:  Add event failed.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Update
        buttonUpdateEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedEvent != null) {
                    String eventDate = editTextDate.getText().toString();
                    String eventTime = editTextTime.getText().toString();
                    String eventDescription = editTextDescription.getText().toString();

                    selectedEvent.setDate(eventDate);
                    selectedEvent.setTime(eventTime);
                    selectedEvent.setDescription(eventDescription);

                    if (dataBaseHelper.updateEvent(selectedEvent.getId(), eventDate, eventTime,
                            eventDescription)) {
                        Toast.makeText(EventsListingActivity.this, "Event updated successfully", Toast.LENGTH_SHORT).show();
                        // Clear the EditText fields
                        editTextDate.setText("");
                        editTextTime.setText("");
                        editTextDescription.setText("");
                        selectedEvent = null;
                        loadEvents(userId);
                    } else {
                        Toast.makeText(EventsListingActivity.this, "Failed to update event", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(EventsListingActivity.this, "Please select an event to update", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Delete event
        buttonDeleteEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedEvent != null) {
                    if (dataBaseHelper.deleteEvent(selectedEvent.getId())) {
                        Toast.makeText(EventsListingActivity.this, "Event deleted successfully", Toast.LENGTH_SHORT).show();
                        // Clear the EditText fields
                        editTextDate.setText("");
                        editTextTime.setText("");
                        editTextDescription.setText("");
                        selectedEvent = null;
                        loadEvents(userId);
                    } else {
                        Toast.makeText(EventsListingActivity.this, "Failed to delete event", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(EventsListingActivity.this, "Please select an event to delete", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Click listener for individual list item
        // Set item click listener for the ListView
        listViewEventsListing.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedEvent = (EventModel) parent.getItemAtPosition(position);
                // Update the EditText fields with the selected event's data
                editTextDate.setText(selectedEvent.getDate());
                editTextTime.setText(selectedEvent.getTime());
                editTextDescription.setText(selectedEvent.getDescription());
            }
        });
    }

    // Load events from the database and update the adapter
    private void loadEvents(int userId) {
        List<EventModel> eventList = dataBaseHelper.getAllEvents(userId);
        eventArrayAdapter.clear();
        eventArrayAdapter.addAll(eventList);
        eventArrayAdapter.notifyDataSetChanged();
    }
}
